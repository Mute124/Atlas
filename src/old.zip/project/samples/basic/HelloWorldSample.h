#pragma once

#include <raylib.h>

class HelloWorldSample  : public Sample {
public:
	HelloWorldSample() : Sample("HelloWorld") {}

	void init() override {
		int a = 0;
		
		
	}
	
	void draw() override {
		// draw a single cube
		
	}
};