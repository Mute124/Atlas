#pragma once
#include "../Common.h"

namespace Atlas {
	class ModLoader {
	public:
		ModLoader();
		~ModLoader();
	};

	class ModManager {
	public:

	private:
		
	};
}