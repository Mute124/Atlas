#include "ModManager.h"

inline Atlas::ModLoader::ModLoader() {}

inline Atlas::ModLoader::~ModLoader() {}
