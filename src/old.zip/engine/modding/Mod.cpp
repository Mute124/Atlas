#include "Mod.h"

inline Atlas::Mod::Mod() {}

inline Atlas::Mod::~Mod() {}
