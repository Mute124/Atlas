#pragma once
#include "IEntity.h"

namespace Atlas {
	class Entity {};
}