#pragma once

namespace Atlas {
	class ICuller abstract {
	public:

	};
}