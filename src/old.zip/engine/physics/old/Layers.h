#pragma once
#include "../utils/Singleton.h"

namespace Techstorm {
}
