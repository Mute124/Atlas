#pragma once

#include <unordered_map>
#include <tinyxml2.h>

#include "../utils/Singleton.h"
#include "Language.h"
namespace Atlas {
	// TODO: This
	/// \todo This
	class LocalizationRegistry : public Singleton<LocalizationRegistry> {
	protected:

	};
}