#pragma once

namespace Atlas {
	/// \note Not yet implemented
	/// TODO: implement
	class MemoryStatus {
	private:

	public:
	};
}