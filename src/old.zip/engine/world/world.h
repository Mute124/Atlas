#pragma once

namespace Atlas {
}