#pragma once

namespace Atlas {
	class IWorldGenerator abstract {
	public:
		virtual void generate() = 0;

	};
}