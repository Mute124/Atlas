#include "FileMeta.h"

Atlas::FileMeta::FileMeta() {
}
