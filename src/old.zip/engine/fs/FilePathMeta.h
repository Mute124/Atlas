#pragma once
#include <string>

namespace Techstorm {
	using FilePathMeta = struct {
		const std::string cPath;
		const std::string cDirectoryName;
	};
}
