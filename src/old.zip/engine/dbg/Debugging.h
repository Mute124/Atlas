#pragma once

namespace Atlas {
	// TODO: Implement debugging and debuggables.
}