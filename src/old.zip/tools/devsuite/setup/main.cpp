#include <iostream>
#include <string>

#include <raygui.h>
#include <raylib.h>
#include <libconfig.h++>

using namespace std;
using namespace libconfig;

int main(int argc, char* argv[]) {
	int returnCode = EXIT_SUCCESS;
	//argh::parser cmdl(argv);

	return returnCode;
}
