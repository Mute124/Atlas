#pragma once
#include <iostream>
#include <unordered_map>




namespace Techstorm {
	namespace DevTools {
		namespace SetupTool {
			class CMDLineArgumentsHandler {
			public:



			private:

				//std::unordered_map<> mArgActionsMap;
			};
		}
	}
}