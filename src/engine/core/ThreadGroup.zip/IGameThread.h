#pragma once
#include <iostream>
#include <string>
#include <thread>
#include <vector>
#include <mutex>
#include <memory>
#include <condition_variable>
#include <functional>

namespace Atlas {

}