#pragma once

#include "InputAction.h"
#include "IInputEventObserver.h"

namespace Atlas {
	class InputEventManager {
	private:

	public:

	};
}
