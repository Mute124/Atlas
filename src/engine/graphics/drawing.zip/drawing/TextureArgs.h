#pragma once

namespace Atlas {
	/// <summary>
	/// 
	/// </summary>
	struct TextureArgs {

	};
}