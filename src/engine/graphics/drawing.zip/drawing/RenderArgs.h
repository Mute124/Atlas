#pragma once

namespace Atlas {
	/// <summary>
	/// 
	/// </summary>
	struct RenderArgs {

	};
}