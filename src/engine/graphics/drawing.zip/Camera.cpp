#include "Camera.h"
#include <raylib.h>

Techstorm::GameCamera::update()
{
	
}
